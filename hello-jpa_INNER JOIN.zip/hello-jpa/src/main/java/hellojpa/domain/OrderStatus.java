package hellojpa.domain;

import java.util.Arrays;
import java.util.List;

public enum OrderStatus {
    ORDER,
    CANCLE;

    public static final List<OrderStatus> CANCELABLE_STATUS = Arrays.asList(ORDER, CANCLE);

    public static boolean isCancelableStatus(OrderStatus status){
        return CANCELABLE_STATUS.contains(status);
    }
}
