package hellojpa.domain;

import hellojpa.domain.member.entity.Member;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

public class JpaMain {
    public static void main(String[] args) {

        // 프로세스당 생성
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        // 트랜잭션당 생성
        EntityManager em = emf.createEntityManager();

        // 트랜잭션 시작
        EntityTransaction tx = em.getTransaction();
//        tx.begin();

        try {
//            11.Join
            //INNER 명시
            List<Member> result = em.createQuery(
                    "SELECT m FROM Member m " +
                            "INNER JOIN m.ORDER o " +
//                            "ON m.MEMBER_ID=o.MEMBER_ID ",
                            "WHERE m.order.id = :id",
                    Member.class
            )//.setParameter("id", 3L )
                    .getResultList();

//            for (Member member : result) {
//                System.out.println("Member=" + member);
//            }

//            10.페이징 API
//            List<Member> resultList = em.createQuery(
//                    "SELECT m FROM Member m ORDER BY m.age",
//                    Member.class
//            ).setFirstResult(1)
//                    .setMaxResults(2)
//                    .getResultList();
//
//            for (Member member : resultList) {
//                System.out.println("MEMBER=" + member);
//            }

//            9.DTO
//            List<UserDto> result = em.createQuery(
//                    "SELECT new hellojpa.domain.DTO.UserDto (m.name, m.age)" +
//                            "FROM Member m",
//                    UserDto.class
//            ).getResultList();
//
//                    for (UserDto user : result) {
//                        System.out.println("맞춤: " + user);
//                    }

            //8.프로젝션(SELECT절 조회 대상 지정)
            //8-1.앤티티(객체) 통째로 조회
//            List<Member> members = em.createQuery(
//                    "SELECT m FROM Member m",
//                    Member.class
//            ).getResultList();
//
//            for (Member member : members){
//                System.out.println("Member=" + member.toString());
//            }

//            8-2.임베디드 타입(시작점으로는 사용하지 못하므로, 반드시시 엔티티 거쳐서 사용
//                        "SELECT a FROM Address a",
//            List<Address> address = em.createQuery(
//                        "SELECT m.address FROM Member m",
//                        Address.class
//                ).getResultList();
//
//                for (Address add : address){
//                    System.out.println("Address=" + add);
//                }

//                8-3.스칼라 타입 프로젝션(기본 데이터 타입 String, Integer, Double)
//            List<String> name = em.createQuery(
//                    "SELECT m.name FROM Member m",
//                    String.class
//            ).getResultList();
//
//                for (String username : name) {
//                    System.out.println("Username=" + username);
//                }
            //8-3.1.평균값 조회
//            Double averageAge = em.createQuery(
//                    "SELECT avg(m.age) FROM Member m",
//                    Double.class
//            ).getSingleResult();
//
//            System.out.println("평균 나이 = " + averageAge);

            //8-3.2.여러값 타입 동시 조회(Object[])
//            List<Object[]> result = em.createQuery(
//                    "SELECT m.name, m.age FROM Member m"
//            ).getResultList();
//
//            for (Object[] obj : result) {
//                String name = (String) obj[0];
//                Integer age = (Integer) obj[1];
//
//                System.out.println("Member name&age=" + name + " & " + age);
//            }

            //7.JPQL-이름 조회
//            List<Member> members = em.createQuery(
//                    "SELECT m FROM Member m WHERE m.id = :id and m.name = :name",
//                    Member.class
//            ).setParameter("id", 2L)
//            .setParameter("name", "memberA")
//            .getResultList();
//
//            System.out.println("Member ID=1, " + members);

            //6.JPQL-id조회 기능_getSingleResult사용
//            Member member = em.createQuery(
//                    "SELECT m FROM Member m WHERE m.id = :id",
//                    Member.class
//            ).setParameter("id", 1L)
//            .getSingleResult();
//
//            System.out.println("Member ID=1, " + member);


            //5.JPQL-조회 기능
//            List<Member> result = em.createQuery(
//                    "SELECT m FROM Member m",
//                    Member.class
//            ).getResultList();
//
//            for (Member member : result) {
//                System.out.println("Member " + member.toString());
//            }

            //4.JPQL-찾기 기능
//            List<String> singleResult = em.createQuery(
//                    "SELECT m.name FROM Member m WHERE m.name like '김%' ORDER BY m.age DESC",
//                    String.class
//            ).getResultList();
//
//            for (String name : singleResult) {
//                System.out.println("이름: " + name);
//            }
//
//            tx.commit();

            //3. Embaded추후에 값 추가시
//            Member memberA = new Member("memberA", 30, new Address("city", "street", "12345"));
//            Member memberB = new Member("memberB", 50, new Address("caty", "strata", "12347"));
//
//            memberA.updateAddress(new Address("city-Update", "street-Update", "54321"));
//
//            em.persist(memberA);
//            em.persist(memberB);
//
//            tx.commit();
            //2. 다대다 관계 매핑(실무에서 잘 쓰이지 않으므로 생략)


            //1. 일대일 관계 매핑
//            Delivery delivery = new Delivery("부산", "양양로", "14531");
//            delivery.setStatus(READY);
//            em.persist(delivery);
//
//            Member member = new Member("한지민","부산", "양양로", "14531");
//            em.persist(member);
//
//            Order order = new Order();
//            order.setOrderDate(LocalDateTime.now());
//            order.setStatus(CANCEL);
//            order.setDelivery(delivery);
//            order.setMember(member);
//            em.persist(order);
//
//            tx.commit();
//
//            System.out.println("Order ID : " + order.getId());
//            System.out.println("Member ID : " + order.getMember().getId());
//            System.out.println("Delivery Status : " + delivery.getStatus());
//            System.out.println("Delivery Street : " + delivery.getStreet());

        } catch (Exception e) {
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();


    }

}