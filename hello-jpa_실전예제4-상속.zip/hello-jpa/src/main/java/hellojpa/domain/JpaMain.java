package hellojpa.domain;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
    public static void main(String[] args) {

        // 프로세스당 생성
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        // 트랜잭션당 생성
        EntityManager em = emf.createEntityManager();

        // 트랜잭션 시작
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        try {
            //2. 다대다 관계 매핑


            //1. 일대일 관계 매핑
//            Delivery delivery = new Delivery("부산", "양양로", "14531");
//            delivery.setStatus(READY);
//            em.persist(delivery);
//
//            Member member = new Member("한지민","부산", "양양로", "14531");
//            em.persist(member);
//
//            Order order = new Order();
//            order.setOrderDate(LocalDateTime.now());
//            order.setStatus(CANCEL);
//            order.setDelivery(delivery);
//            order.setMember(member);
//            em.persist(order);
//
//            tx.commit();
//
//            System.out.println("Order ID : " + order.getId());
//            System.out.println("Member ID : " + order.getMember().getId());
//            System.out.println("Delivery Status : " + delivery.getStatus());
//            System.out.println("Delivery Street : " + delivery.getStreet());

        } catch (Exception e) {
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();


    }

}