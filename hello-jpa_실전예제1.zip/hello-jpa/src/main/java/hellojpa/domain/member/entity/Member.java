package hellojpa.domain.member.entity;


public class Member {

}
