package hellojpa.domain.orders.entity;

public class Orders {
    
}
