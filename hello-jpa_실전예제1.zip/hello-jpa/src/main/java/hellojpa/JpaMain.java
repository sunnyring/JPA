package hellojpa;

import hellojpa.domain.orders.entity.Orders;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

public class JpaMain {
    public static void main(String[] args) {

        // 프로세스당 생성
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        // 트랜잭션당 생성
        EntityManager em = emf.createEntityManager();

        // 트랜잭션 시작
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        try {

            //양방향 관계 매핑 후 탐색
//            Team team = em.find(Team.class, 99L);
//            List<Member> members =team.getMembers();
//            System.out.println(members.size());
//
//            for(Member member : members) {
//                System.out.println("member.name = " + member.getName());
//            }

//            Member member = em.find(Member.class, 8L);
//            Team team2 = new Team( 99L, "팀999");
//            em.persist(team2); //insert
//            tx.commit();
//
//            tx.begin();
//            //회원1에 새로운 팀2 설정
//            Member member = em.find(Member.class, 4L); //select
//            member.setTeam(team2); //update insert는 최적화..마지막 쿼리

//            다대일 연관관계 비즈니스 로직/
            Team team = new Team();
//            team.setId(1L);
            team.setName("TeamD");
            em.persist(team);

            Member member = new Member();
            member.setName("member4"); //
//            team.getMembers().add(member); //추가
            member.changeTeam(team);
            member.setTeam(team);
            em.persist(member);

            tx.commit();

            //양방향 연관관계 저장
//            Team team1 = new Team()

//            //조회
//            Member findMember = em.find(Member.class, 8L);
//            //참조를 사용해서 연관관계 조회
//            Team findTeam = findMember.getTeam();
//            System.out.println(findMember);

        } catch (Exception e) {
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();


    }
}