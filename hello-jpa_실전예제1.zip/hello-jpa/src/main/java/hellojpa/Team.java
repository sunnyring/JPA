package hellojpa;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Team {

    @Id  @GeneratedValue
    @Column(name = "TEAM_ID")
    private Long id;

    @Column
    private String name;

    @OneToMany(mappedBy = "team")
    List<Member> members = new ArrayList<Member>();


    public Team(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Team() {
    }

    //    @OneToMany(mappedBy = "team")
//    List<Member> members = new ArrayList<Member>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
//    public void setName(String teamA) {
//        this.teamA =
//    }


    public void setName(String name) {
        this.name = name;
    }

    public List<Member> getMembers() {
        return members;
    }

    public void setMembers(List<Member> members) {
        this.members = members;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Team{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }





}
