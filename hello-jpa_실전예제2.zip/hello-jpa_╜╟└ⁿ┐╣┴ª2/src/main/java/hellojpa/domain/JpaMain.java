package hellojpa.domain;

import hellojpa.domain.order_item.entity.OrderItem;
import hellojpa.domain.orders.entity.Order;
import hellojpa.domain.item.entity.Item;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
    public static void main(String[] args) {

        // 프로세스당 생성
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        // 트랜잭션당 생성
        EntityManager em = emf.createEntityManager();

        // 트랜잭션 시작
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        try {
            //0118 연관관계매핑 객체 그래프 탐색
//            Order order = em.find(Order.class, 2l);
//            Member member = order.getMember();
//            System.out.println("OrderID :" + order.getId());
//            System.out.println("OrderID :" + order.getMember().getId());
//            System.out.println("OrderID :" + member.getId());
//            System.out.println("MemberID :" + member.getName());

            Order order = em.find(Order.class, 2L);
            OrderItem orderItem = order.getOrderItems().get(0);
            Item item = orderItem.getItem();
            System.out.println("OrderID : " + order.getId());
            System.out.println("OrderID : " + orderItem.getOrder().getId());
            System.out.println("Order_Item ID : " + orderItem.getId());
            System.out.println("Order_Item Name : " + orderItem.getItem().getName());

//            Member member1 = new Member("이정민", "사울", "가곡나루로", "나양동");
//            em.persist(member1);
//
//            Order order = new Order();
//            order = em.find(Order.class, 2L);
////            Order order = em.find(Order.class, 2L);
//            Member member = order.getMember(member1);
//            em.persist(order);

            //양방향 관계 매핑 후 탐색
//            Team team = em.find(Team.class, 99L);
//            List<Member> members =team.getMembers();
//            System.out.println(members.size());
//
//            for(Member member : members) {
//                System.out.println("member.name = " + member.getName());
//            }

//            Team team = em.find(Team.class, 2L);

            //f
//            Order order = em.find(Order.class, 1L);
//            orderItem = order.getOrderItems().get(0); //index
//            Item = orderItem.getItem();


            //1.데이터 추가 (ORDERS - MEMBER)
//            Member member1 = new Member("김정민", "서울", "마곡나루로", "가양동");
//            em.persist(member1);
//
//            Order order1 = new Order();
//            order1.getMember(member1);
//            em.persist(order1); //insert

            tx.commit();

//            Member member1 = new Member();
//            member1.setName("김정민");
//            member1.setCity("서울");
//            member1.setStreet("마곡나루로");
//            member1.setStreet("가양동");
//            em.persist(member1);
//            tx.commit();

//            Order order1 = new Order();
//            order1.getMember(member1);
//            em.persist(order1); //insert



            //참고(MEMBER - TEAM) 다 쪽에 changeTeam메서드
//            Team team1 = new Team("TeamC");
//            em.persist(team1);
//
//            Member member1 = new Member("수지");
//            member1.setTeam(team1); //setTeam메서드 이름 변경
//            member1.changeTeam(team1);//setTeam메서드
//            em.persist(member1);
//
//            Member member2 = new Member("페이");
////            member2.changeTeam(member2); //양방향 설정
//            member2.changeTeam(team1);
//            em.persist(member2);


//0117 기존데이터에 매핑하여 추가
//            Team team1 = em.find(Team.class, 2L); //select
//            Member member3 = new Member("미카");
////            member3.setName("민");//insert
//            member3.changeTeam(team1);
//            em.persist(member3);
//            tx.commit();

//            Team team1 = new Team("TeamC");
//            em.persist(team1);
//
//            Member member1 = new Member("수지");
////            member1.setTeam(team1); //setTeam메서드 이름 변경
//            member1.changeTeam(team1);//setTeam메서드
//            em.persist(member1);
//
//            Member member2 = new Member("페이");
////            member2.changeTeam(member2); //양방향 설정
//            member2.changeTeam(team1);
//            em.persist(member2);
//
//            Member member3 = new Member("민");
//            member3.changeTeam(team1);
//            //em.persist(member2)
//            tx.commit();

            //시행착오
//            Member member3 = em.find(Member.class, 5L);
//            Team findTeam = member3.getTeam();
//            tx.commit();

//            //조회
//            Member findMember = em.find(Member.class, 8L);
//            //참조를 사용해서 연관관계 조회
//            Team findTeam = findMember.getTeam();
//            System.out.println(findMember);

            //양방향 관계 매핑 후 탐색
//            Team team = em.find(Team.class, 99L);
//            List<Member> members =team.getMembers();
//            System.out.println(members.size());
//
//            for(Member member : members) {
//                System.out.println("member.name = " + member.getName());
//            }

//            Team team = em.find(Team.class, 2L);




//연관관계로 조회
//            Member member = em.find(Member.class, 8L);
//            Team team2 = new Team( 99L, "팀999");
//            em.persist(team2); //insert
//            tx.commit();
//
//            tx.begin();
//            //회원1에 새로운 팀2 설정
//            Member member = em.find(Member.class, 4L); //select
//            member.setTeam(team2); //update insert는 최적화..마지막 쿼리

//            다대일 연관관계 비즈니스 로직/
//            Team team = new Team();
////            team.setId(1L);
//            team.setName("TeamH"); //insert
//            em.persist(team); //
//
//            Member member = new Member();
//            member.setName("member8"); //
//            member.changeTeam(team); //setTeam
////            team.getMembers().add(member); //추가
////            member.setTeam(team);
//            em.persist(member);
//
//            tx.commit();


            //양방향 연관관계 저장
//            Team team1 = new Team()





        } catch (Exception e) {
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();


    }
}