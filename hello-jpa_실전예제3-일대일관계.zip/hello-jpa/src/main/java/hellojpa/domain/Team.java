package hellojpa.domain;

import hellojpa.domain.Member;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Team {
    /**
    project시작할 때, @GenernatedValue의 유무에 따라 설명
     @GenernatedValue는 선언되어 있는 필드(컬럼)에 대해 ID자동 발급기 객체를 삽입해줌
     테이블을 생성하기 위해 hbm2ddl.auto(DDL 설정단계)를 create으로 설정해둔 상태.
     1.없을때, @Id만을 매핑하여 id 자동발급기가 생성되지 않는다.
     2.있을때, @GenernatedValue가 ID 자동 발급기 객체를 삽입
     테이블 생성 후 hbm2ddl.auto(DDL 설정단계)를 validate로 설정 변경하면
     @Entity 객체들과 DB에 생성되어 있는 테이블들이 일치하는지 검사만 한다.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TEAM_ID")
    private Long id;

//    @Column
    private String name;

    @OneToMany(mappedBy = "team")
    List<Member> members = new ArrayList<Member>();

    public Team(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Team(String name) {
        this.name = name;
    }

    public Team(Long id) {
        this.id = id;
    }

    public Team() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
//    public void setName(String teamA) {
//        this.teamA =
//    }


    public void setName(String name) {
        this.name = name;
    }

    public List<Member> getMembers() {
        return members;
    }

    public void setMembers(List<Member> members) {
        this.members = members;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Team{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }





}
