package hellojpa.domain;

import hellojpa.domain.entity.Address;
import hellojpa.domain.member.entity.Member;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
    public static void main(String[] args) {

        // 프로세스당 생성
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        // 트랜잭션당 생성
        EntityManager em = emf.createEntityManager();

        // 트랜잭션 시작
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        try {
            //3. Embaded추후에 값 추가시
            Member memberA = new Member("memberA", 30, new Address("city", "street", "12345"));
            Member memberB = new Member("memberB", 50, new Address("caty", "strata", "12347"));

            memberA.updateAddress(new Address("city-Update", "street-Update", "54321"));

            em.persist(memberA);
            em.persist(memberB);

            tx.commit();
            //2. 다대다 관계 매핑(실무에서 잘 쓰이지 않으므로 생략)


            //1. 일대일 관계 매핑
//            Delivery delivery = new Delivery("부산", "양양로", "14531");
//            delivery.setStatus(READY);
//            em.persist(delivery);
//
//            Member member = new Member("한지민","부산", "양양로", "14531");
//            em.persist(member);
//
//            Order order = new Order();
//            order.setOrderDate(LocalDateTime.now());
//            order.setStatus(CANCEL);
//            order.setDelivery(delivery);
//            order.setMember(member);
//            em.persist(order);
//
//            tx.commit();
//
//            System.out.println("Order ID : " + order.getId());
//            System.out.println("Member ID : " + order.getMember().getId());
//            System.out.println("Delivery Status : " + delivery.getStatus());
//            System.out.println("Delivery Street : " + delivery.getStreet());

        } catch (Exception e) {
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();


    }

}