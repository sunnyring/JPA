package hellojpa.domain.entity;

import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;
@MappedSuperclass
public class BaseEntity {
    private LocalDateTime createdDate;       //등록일
    private LocalDateTime lastModifiedDate;  //수정일
}
